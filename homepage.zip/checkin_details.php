<!DOCTYPE html>
<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap4.min.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet">
    <style>
        .w-50 {
            width: 64%!important;
        }
        p {
            margin-top: 80px;
            margin-bottom: 1rem;
        }
    </style>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">COMAPANY NAME</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home Page <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="check_in.php">Check-in<span class="sr-only">(current)</span></a>
            </li>
        </ul>
    </div>
</nav>
</br>
<table class="table table-bordered">
    <thead>
    <tr>
        <th scope="col">Sl.no</th>
        <th scope="col">First Name</th>
        <th scope="col">Last Name</th>
        <th scope="col">Company Name</th>
        <th scope="col">Purpose Of Visit</th>

    </tr>
    </thead>
    <tbody>
    <tr>

    </tr>
    <tr>

    </tr>
    <tr>

    </tr>
    </tbody>
</table>
</body>

